package com.spring.web.model.service;

import java.util.List;

import com.spring.web.model.EmployeeModel;

public interface EmployeeService{
	EmployeeModel saveEmployee(EmployeeModel employee);
	List<EmployeeModel> getAllEmployees();

}
