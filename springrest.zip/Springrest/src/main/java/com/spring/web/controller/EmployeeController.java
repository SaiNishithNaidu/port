package com.spring.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.web.model.EmployeeModel;
import com.spring.web.model.service.EmployeeService;

@RestController
@RequestMapping("/cts/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	//build create Employee REST ApI
	@PostMapping
	public ResponseEntity<EmployeeModel> saveEmployee(@RequestBody EmployeeModel employee){
		return new ResponseEntity<EmployeeModel>(employeeService.saveEmployee(employee), HttpStatus.CREATED);
		
	}
	
	//build get all employees REST API
	@GetMapping
	public List<EmployeeModel> getAllEmployees(){
		return employeeService.getAllEmployees();
		
	}
	
}
