package com.spring.web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.web.model.EmployeeModel;
import com.spring.web.model.service.EmployeeService;
import com.spring.web.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}
	
	@Override
	public EmployeeModel saveEmployee(EmployeeModel employee) {
		
		return employeeRepository.save(employee);
	}

	@Override
	public List<EmployeeModel> getAllEmployees() {
		return employeeRepository.findAll(); 
	}
}
