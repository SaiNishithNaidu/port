package com.example.Project.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.Project.Model.AddFacilitiesModel;
import com.example.Project.Model.FacilityAppointmentCreateModel;
import com.example.Project.Model.RegisterDoctorModel;

@Service
public class HospitalAdminService {
	@Autowired
	JdbcTemplate jdbcTemplate;


	public List<RegisterDoctorModel> AllDoctors() {
		List<RegisterDoctorModel> s = new ArrayList<RegisterDoctorModel>();
		List<RegisterDoctorModel> users= jdbcTemplate.query("select * from register_doctor;", new BeanPropertyRowMapper(RegisterDoctorModel.class));
		s.addAll(users);
	return s;
	}


	public List<RegisterDoctorModel> DoctorsInOurHospital(String id) {
		List<RegisterDoctorModel> users1 = new ArrayList<RegisterDoctorModel>();
		List<String> ids= jdbcTemplate.queryForList("select id from hospital_"+id+"Doctors",String.class);
		for(String k:ids) {
			List<RegisterDoctorModel> users= jdbcTemplate.query("select * from register_doctor where id ="+k+";", new BeanPropertyRowMapper(RegisterDoctorModel.class));
			users1.addAll(users);
		}
		
		
	return users1;
	}


	public void addToHospitalDatabase(String select,String hospitalid) {
		String sql = "insert into hospital_"+hospitalid +"Doctors values("+select+");";
		jdbcTemplate.execute(sql);
		
	}


	public void removeToHospitalDatabase(String deselect, String hospitalid) {
		String sql = "DELETE FROM hospital_"+hospitalid +"Doctors WHERE id = "+deselect+";";
		jdbcTemplate.execute(sql);
		
	}




	public boolean checkIfPresent(String select, String hospitalid) {
		List<String> users= jdbcTemplate.queryForList("select id from hospital_"+hospitalid+"Doctors where id ="+select+";",String.class);
		if(users.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}
	
	public Boolean addFacilitiesToDatabase(AddFacilitiesModel addFacilitiesModel,String id) {
		String sql = "insert into hospital_"+id+"Facilities"+" (Facility,Description_of_Facilities,Remarks_of_Facilities)values("
				+ "\"" + addFacilitiesModel.getFacility() + "\"" + "," + "\""
				+ addFacilitiesModel.getDescription_of_Facilities() + "\"" + "," + "\""
				+ addFacilitiesModel.getRemarks_of_Facilities() + "\"" + ");";
		jdbcTemplate.execute(sql);
		return true;
	}
	public Boolean updateFacilitiesToDatabase(AddFacilitiesModel addFacilitiesModel,String id) {
		String sql = "update hospital_"+id+"Facilities SET"+" Description_of_Facilities =\""+addFacilitiesModel.getDescription_of_Facilities()+"\","+
				" Remarks_of_Facilities =\""+addFacilitiesModel.getRemarks_of_Facilities()+"\" where Facility=\""+addFacilitiesModel.getFacility()+"\";";
		jdbcTemplate.execute(sql);
		return true;
	}


	public List<FacilityAppointmentCreateModel> viewAppointments(String k) {
			List<FacilityAppointmentCreateModel> appointments = jdbcTemplate.query("select * from hospital_"+k+"Appointments;", new BeanPropertyRowMapper(FacilityAppointmentCreateModel.class));
			return appointments;
		
	}



	public void changeStatus(String hospitalid,String id,String Status) {
		String sql3 = "select * from hospital_"+hospitalid+"appointments where id ="+id;
		List<FacilityAppointmentCreateModel> user = jdbcTemplate.query(sql3, new BeanPropertyRowMapper(FacilityAppointmentCreateModel.class));
		String sql = "update hospital_"+hospitalid+"appointments SET"+" Status =\""+Status+"\" "+ "where id=\""+id+"\";";
		String sql1 = "update patient_"+user.get(0).getPATID()+"appointments SET"+" Status =\""+Status+"\" "+ "where Time=\""+user.get(0).getTime()
		+"\" and Facility=\""+user.get(0).getFacility()
		+"\" and Date=\""+user.get(0).getDate()
		+"\" and Remarks=\""+user.get(0).getRemarks()+"\";";
		jdbcTemplate.execute(sql);
		jdbcTemplate.execute(sql1);
		
		
	}
	
	
	
}
