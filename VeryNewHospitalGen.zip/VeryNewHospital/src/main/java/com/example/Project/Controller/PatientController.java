package com.example.Project.Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.DeleteBuilder.DeleteWhereAndOr;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.Project.Model.DoctorAppointmentCreateModel;
import com.example.Project.Model.FacilityAppointmentCreateModel;
import com.example.Project.Model.FacilityAppointmentModel;
import com.example.Project.Model.RegisterDoctorModel;
import com.example.Project.Model.RegisterHospitalAdminModel;
import com.example.Project.Service.PatientService;

@Controller
@SessionAttributes("id")
public class PatientController {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	PatientService patientService;

	
	


	@GetMapping("/ViewHospital_p" )
	public String ViewHospital(ModelMap map) {
		List<String> hospitalNames = new ArrayList<>();
		List<String> hospitalid = new ArrayList<>();
		List<String> hospitalAddress = new ArrayList<>();
		for(RegisterHospitalAdminModel k:patientService.fetchHospitals()) {
			hospitalNames.add(k.getHospital_Name());
			hospitalAddress.add(k.getAddress_Lane1()+" "+k.getAddress_Lane2()+" "+k.getAddress_Lane3()+" "+k.getCity()+" "+k.getState());
			hospitalid.add(k.getHospital_Id());
		}
		map.addAttribute("hospitalname", hospitalNames);
		map.addAttribute("hospitaladdress", hospitalAddress);
		map.addAttribute("hospitalid", hospitalid);
		return "ViewHospital_p";
	}

	@GetMapping("/BookAppointment_p" )
	public String BookAppointment() {
		return "BookAppointment_p";
	}
	@GetMapping("/Doctor_Appointment_p")
	public String DoctorAppointment() {
		return "Doctor_Appointment_p";
	}
	@GetMapping("/afterAppointment")
	public String afterDoctorAppointment(
			@ModelAttribute("DoctorAppointmentCreateModel") DoctorAppointmentCreateModel doctorAppointmentCreateModel, ModelMap map) {
		System.out.println(doctorAppointmentCreateModel.toString());
		String doctorId= patientService.checkIfDoctorAvailable(doctorAppointmentCreateModel.getDoctor_Name());
		if(doctorId.equals("")) {
			map.addAttribute("error","please enter the correct doctor name");
			return "Doctor_Appointment_p";
		}else {
			patientService.BookAppointmentDoctor(doctorAppointmentCreateModel,doctorId,map.get("id").toString());
			return "afterAppointment";
		}
	}
	@GetMapping("/Facilities_Appointment_p")
	public String FacilitiesAppointment() {
		return "Facilities_Appointment_p";
	}

	@GetMapping("/afterAppointment1")
	public String afterFacilityAppointment(
			@ModelAttribute("FacilityAppointmentModel") FacilityAppointmentModel facilityAppointmentModel, ModelMap map) {
		
		String hospitalId = patientService.checkHospitalNameAvaliable(facilityAppointmentModel.getHospital_Name());
		if(hospitalId.equals("")) {
			map.addAttribute("error","please enter the correct hospital name");
			return "Facilities_Appointment_p";
		}else {
			patientService.BookAppointmentFacility(facilityAppointmentModel,hospitalId,map.get("id").toString());
			return "afterAppointment";
			
		}
		
		
		
	}

	@GetMapping("/ViewAppointment_p" )
	public String ViewAppointment(ModelMap map) {
		List<FacilityAppointmentCreateModel> users = patientService.viewAppointments(map.get("id").toString());
		map.addAttribute("appointments", users);
		return "ViewAppointment_p";
	}
	@GetMapping("/ViewTestResult_p" )
	public String ViewTestResult() {
		return "ViewTestResult_p";
	}
	
	
	@GetMapping("/ViewHospital" )
	public String ViewHospital(@RequestParam String HospitalID,ModelMap map) {
	RegisterHospitalAdminModel k = patientService.fetchHospitalDetails(HospitalID);
		map.addAttribute("HospitalName", k.getHospital_Name());
		map.addAttribute("HospitalContactNumber", k.getHospital_Contact_Number());
		map.addAttribute("HospitalFaxNumber", k.getHospital_Fax_Number());
		map.addAttribute("HospitalWebsite", k.getHospital_Website());
		map.addAttribute("HospitalID", HospitalID);
		System.out.println(HospitalID);
		return "ViewHospital";
	}
	
	
	@GetMapping("/ViewHospitalFacilities" )
	public String ViewHospitalFacilities(@RequestParam String HospitalID,ModelMap map) {
		List<String> k = patientService.fetchFacilities(HospitalID);
		map.addAttribute("facilities",k );
		map.addAttribute("HospitalName",HospitalID);
		return "ViewHospitalFacilities";
	}
	
	@GetMapping("/ViewHospitalFacilitiesNames" )
	public String ViewHospitalFacilitiesNames(@RequestParam String FacilityName,@RequestParam String HospitalName,ModelMap map) {
		List<String> k = patientService.fetchFacilitiesDetails(FacilityName,HospitalName);
		map.addAttribute("facilitiesDetails",k);
		return "ViewHospitalFacilitiesDetails";
	}

	
	
	@GetMapping("/ViewHospitalDoctor" )
	public String ViewHospitalDoctor(@RequestParam String HospitalID,ModelMap map) {
		List<String> k = patientService.fetchDoctorID(HospitalID);
		System.out.println(HospitalID);
		 List<RegisterDoctorModel> docDetails = patientService.fetchDoctorFromTable(k);
		map.addAttribute("doctorID",k );
		map.addAttribute("DoctorDetails", docDetails);
		return "ViewHospitalDoctor";
	}
	
	@GetMapping("/ViewHospitalDoctorID" )
	public String ViewHospitalDoctorID(@RequestParam String DoctorID,@RequestParam String HospitalName,ModelMap map) {
		List<RegisterDoctorModel> docDetails = patientService.fetchDoctorFromTable(Arrays.asList(DoctorID));
		map.addAttribute("DoctorDetails", docDetails);
		return "ViewHospitalDoctorDetails";
	}

	
}
