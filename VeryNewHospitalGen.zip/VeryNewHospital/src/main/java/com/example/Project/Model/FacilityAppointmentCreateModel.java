package com.example.Project.Model;

public class FacilityAppointmentCreateModel {
	private String id;
	private String PATID;
	private String Time;
	private String Facility;
	private String Date;
	private String Status;
	private String Remarks;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPATID() {
		return PATID;
	}
	public void setPATID(String pATID) {
		PATID = pATID;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public String getFacility() {
		return Facility;
	}
	public void setFacility(String facility) {
		Facility = facility;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	@Override
	public String toString() {
		return "FacilityAppointmentCreateModel [id=" + id + ", PATID=" + PATID + ", Time=" + Time + ", Facility="
				+ Facility + ", Date=" + Date + ", Status=" + Status + ", Remarks=" + Remarks + "]";
	}

	

}
