package com.example.Project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.Project.Model.AddFacilitiesModel;
import com.example.Project.Model.FacilityAppointmentCreateModel;
import com.example.Project.Service.HospitalAdminRegisterService;
import com.example.Project.Service.HospitalAdminService;
import com.example.Project.Service.PatientService;

@Controller
@SessionAttributes("id")
public class HospitalAdminController {
	
	@Autowired
	HospitalAdminRegisterService hospitalAdminRegisterService;
	@Autowired
	PatientService patientService;
	@Autowired
	HospitalAdminService hospitalAdminService;

	@GetMapping(path = "/AddFacilities_h")
	public String AddFacilities(ModelMap map) {
		System.out.println(map.get("id"));
		List<String> hospitalname=hospitalAdminRegisterService.getHospitalName(map.get("id").toString());
		map.addAttribute("hospitalid",map.get("id").toString());
		map.addAttribute("hospitalname",hospitalname.get(0));
		return "AddFacilities_h";
	}
	
	@GetMapping("/afterAddFacilities")
	public String afterAddFacilities(@ModelAttribute("AddFacilitiesModel") AddFacilitiesModel addFacilitiesModel, ModelMap map) {
		hospitalAdminService.addFacilitiesToDatabase(addFacilitiesModel,map.get("id").toString());
		return "afterAddFacilities";
	}
	@GetMapping("/updateFacilities")
	public String updateFacilities(@ModelAttribute("AddFacilitiesModel") AddFacilitiesModel addFacilitiesModel, ModelMap map) {
		hospitalAdminService.updateFacilitiesToDatabase(addFacilitiesModel,map.get("id").toString());
		return "afterAddFacilities";
	}
	
	
	@GetMapping("/UpdateFacilities_h")
	public String UpdateFacilities() {
		return "UpdateFacilities_h";
	}
	
	
	@GetMapping("/Doctors_h")
	public String Doctors(ModelMap map) {
		map.addAttribute("registeredDoctors", hospitalAdminService.AllDoctors());
		map.addAttribute("DoctorsInHospital",hospitalAdminService.DoctorsInOurHospital(map.get("id").toString()));	 
		return "Doctors_h";
	}
	
	@GetMapping("/Doctors1_h")
	public String Doctors1(@RequestParam String select, ModelMap map) {
		if(!hospitalAdminService.checkIfPresent(select,map.get("id").toString())) {
			hospitalAdminService.addToHospitalDatabase(select,map.get("id").toString());
		}
		map.addAttribute("registeredDoctors", hospitalAdminService.AllDoctors());
		map.addAttribute("DoctorsInHospital",hospitalAdminService.DoctorsInOurHospital(map.get("id").toString()));	 
		return "Doctors_h";
	}
	
	@GetMapping("/Doctors2_h")
	public String Doctors2(@RequestParam String deselect, ModelMap map) {
		hospitalAdminService.removeToHospitalDatabase(deselect,map.get("id").toString());
		map.addAttribute("registeredDoctors", hospitalAdminService.AllDoctors());
		map.addAttribute("DoctorsInHospital",hospitalAdminService.DoctorsInOurHospital(map.get("id").toString()));	 
		return "Doctors_h";
	}
	
	
	@GetMapping("/ViewAppointment_h")
	public String ViewAppointment(ModelMap map) {
		List<FacilityAppointmentCreateModel> appointments = hospitalAdminService.viewAppointments(map.get("id").toString());
		map.addAttribute("appointments", appointments);
		return "ViewAppointment_h";
	}
	@GetMapping("/ViewAppointmentAccept_h")
	public String ViewAppointmentaccept(@RequestParam String accept, ModelMap map) {
		List<FacilityAppointmentCreateModel> appointments = hospitalAdminService.viewAppointments(map.get("id").toString());
		hospitalAdminService.changeStatus(map.get("id").toString(),accept,"Approve");
		map.addAttribute("appointments", appointments);
		return "ViewAppointment_h";
	}
	@GetMapping("/ViewAppointmentReject_h")
	public String ViewAppointmentreject(@RequestParam String reject, ModelMap map) {
		List<FacilityAppointmentCreateModel> appointments = hospitalAdminService.viewAppointments(map.get("id").toString());
		map.addAttribute("appointments", appointments);
		hospitalAdminService.changeStatus(map.get("id").toString(),reject,"Reject");
		return "ViewAppointment_h";
	}

	@GetMapping("/UpdateTestResult_h")
	public String UpdateTestResult() {
		return "UpdateTestResult_h";
	}

	@GetMapping("/Billing_h")
	public String Billing() {
		return "Billing_h";

	}
}
